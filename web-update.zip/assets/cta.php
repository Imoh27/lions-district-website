
     
          <div class="row">
            <div class="col-md-4">
              <div class="subscribe-call-to-acton">
                <h3>Be Part of Us</h3>
                <p>Join a community dedicated to making a lasting impact.</p>
                <!-- <h2>(+9) 847-291-4353</h2> -->
              </div>
            </div>
            <!-- Col end -->

            <div class="col-md-8">
              <div class="ts-newsletter row align-items-center justify-content-center">
                <div class="col-md-5 newsletter-introtext">
                  <h4 class="text-white mb-0">Join Us</h4>
                  <p class="text-white">Make a difference today</p>
                </div>
                <div class="call-to-action-btn "></div>
                  <a class="btn btn-alt " href="#">Join Now</a>
                </div>

              </div>
              <!-- Newsletter end -->
            </div>
            <!-- Col end -->
          </div>
          <!-- Content row end -->
       