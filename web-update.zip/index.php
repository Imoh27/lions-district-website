<?php
  header("location: home");
?>