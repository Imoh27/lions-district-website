<?php if(isset($x_content) && $x_content): ?>
</div>
</div>
</div>
</div>
<?php endif; ?>
</div>
<!-- /page content -->
<!-- footer content -->
<footer>
<div class="m-auto text-center">
<span
                    >&copy; <script>
                      document.write(new Date().getFullYear());
                    </script> Lions Clubs District 404A2.
                  </span>
</div>
<div class="clearfix"></div>
</footer>
<!-- /footer content -->
</div>
</div>